const imagens = document.querySelectorAll (".a_box_products img")
console.log(imagens)
const botaoprev = document.querySelector(".prev")
const botaonext = document.querySelector(".next")


console.log(botaoprev)

let imagematual = 0
function mostrarimagem(indice){
    imagens.forEach ((imagem, i) =>{
        if (i===indice){
            console.log("sou chamado 1 ")
            imagem.classList.add("active")
        }else{
            console.log("sou chamado 2 ")
            imagem.classList.remove("active")
        }
    })
}

botaoprev.addEventListener("click",function(){
    console.log("voltar")
    imagematual=imagematual-1
    if (imagematual<0){
        imagematual=imagens.length-1
    }
    mostrarimagem(imagematual)
    console.log(imagematual)
    console.log(imagens)
})

botaonext.addEventListener("click",function(){
    console.log("proximo")
    imagematual=imagematual+1
    if (imagematual>imagens.length){
        imagematual = 0
    }
    mostrarimagem(imagematual)
    console.log(imagematual)
    console.log(imagens)
})

